import Navigation from "../components/Navigation.jsx"

function Home() {
    return (
        <>
            <Navigation />
            Home
        </>
    )
}

export default Home